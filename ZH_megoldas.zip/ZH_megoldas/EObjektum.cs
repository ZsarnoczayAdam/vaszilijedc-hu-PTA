﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZH_megoldas
{
    enum KozeppontHely { Tengelyen, JobbFélsík, Balfélsík }
    class EObjektum
    {
        private double kx;
        private double ky;
        private double kr;
        private string knev;
        private KozeppontHely kpHely;

        public EObjektum(double kx, double ky, double kr, string knev)
        {
            this.kx = kx;
            this.ky = ky;
            this.kr = kr;
            this.knev = knev;
        }

        public KozeppontHely KpTipus()
        {
            if (kx == 0)
            {
                kpHely = KozeppontHely.Tengelyen;
            }
            else if (kx > 0)
            {
                kpHely = KozeppontHely.JobbFélsík;
            }
            else
            {
                kpHely = KozeppontHely.Balfélsík;
            }
            return kpHely;
        }

        public double Kx
        {
            get { return kx; }
        }

        public double Ky
        {
            get { return ky; }
        }

        public double Kr
        {
            get { return kr; }
        }

        public string Knev
        {
            get { return knev; }
        }

        public double Tavolsag()
        {
            double tavolsag = Math.Sqrt(kx * kx + ky * ky);
            return tavolsag;
        }

        public override string ToString()
        {
            return string.Format($"{knev}, középpont: ({kx}; {ky}) r: {kr} {kpHely}");
        }
    }
}

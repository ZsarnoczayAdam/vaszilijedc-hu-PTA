﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZH_megoldas
{
    class Program
    {
        static void Main(string[] args)
        {
			try
			{
                List<EObjektum> kraterek = new List<EObjektum>();
                StreamReader sr = new StreamReader("krater.txt");
                while (!sr.EndOfStream)
                {
                    string sor = sr.ReadLine();
                    string[] d = sor.Split(' ');
                    double kx = double.Parse(d[0]);
                    double ky = double.Parse(d[1]);
                    double kr = double.Parse(d[2]);
                    string knev = string.Join(" ", d, 3, d.Length - 3);
                    kraterek.Add(new EObjektum(kx, ky, kr, knev));
                }
                sr.Close();
                foreach (var item in kraterek)
                {
                    Console.WriteLine(item);
                }

                if (kraterek.Count > 0)
                {
                    EObjektum legkozelebbi = kraterek[0];
                    double minTav = legkozelebbi.Tavolsag();
                    foreach (EObjektum krater in kraterek)
                    {
                        double tav = krater.Tavolsag();
                        if (tav < minTav)
                        {
                            minTav = tav;
                            legkozelebbi = krater;
                        }
                    }
                    Console.Write("\nA legközelebbi kráter adatai: ");
                    Console.WriteLine(legkozelebbi);
                }
                else
                {
                    Console.WriteLine("Nincs egyetlen kráter sem a listában.");
                }
			}
			catch (Exception e)
			{

                Console.WriteLine(e.Message);
			}
            Console.ReadLine();
        }
    }
}

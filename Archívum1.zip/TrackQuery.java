/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.musicapp;

/**
 *
 * @author lalat
 */
public class TrackQuery
{
    private int trackId;
    private String trackName;
    private String album;
    private int milliSecond;
    private int bytes;
    private double unitPrice;
    private String artistName;

    public TrackQuery(int trackId, String trackName, String album, int milliSecond, int bytes, double unitPrice, String artistName)
    {
        this.trackId = trackId;
        this.trackName = trackName;
        this.album = album;
        this.milliSecond = milliSecond;
        this.bytes = bytes;
        this.unitPrice = unitPrice;
        this.artistName = artistName;
    }

    public int getTrackId()
    {
        return trackId;
    }

    public void setTrackId(int trackId)
    {
        this.trackId = trackId;
    }

    public String getTrackName()
    {
        return trackName;
    }

    public void setTrackName(String trackName)
    {
        this.trackName = trackName;
    }

    public String getAlbum()
    {
        return album;
    }

    public void setAlbum(String album)
    {
        this.album = album;
    }

    public int getMilliSecond()
    {
        return milliSecond;
    }

    public void setMilliSecond(int milliSecond)
    {
        this.milliSecond = milliSecond;
    }

    public int getBytes()
    {
        return bytes;
    }

    public void setBytes(int bytes)
    {
        this.bytes = bytes;
    }

    public double getUnitPrice()
    {
        return unitPrice;
    }

    public void setUnitPrice(double unitPrice)
    {
        this.unitPrice = unitPrice;
    }

    public String getArtistName()
    {
        return artistName;
    }

    public void setArtistName(String artistName)
    {
        this.artistName = artistName;
    }

    @Override
    public String toString()
    {
        return "TrackQuery{" + "trackId=" + trackId + ", trackName=" + trackName + ", album=" + album + ", milliSecond=" + milliSecond + ", bytes=" + bytes + ", unitPrice=" + unitPrice + ", artistName=" + artistName + '}';
    }
    
}

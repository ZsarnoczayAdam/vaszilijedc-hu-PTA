/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.musicapp;

/**
 *
 * @author lalat
 */


import java.sql.SQLException;
import java.sql.Statement;
import java.sql.*;
import java.util.*;

public class MusicRepository {

    private final String URL = "jdbc:sqlite:Music.db";

    private Statement getStatement() throws SQLException {
        Connection connection = DriverManager.getConnection(URL);
        return connection.createStatement();
    }

    public List<TrackQuery> getAll() {
    Statement st = null;
    ResultSet rs = null;
    try {
        st = getStatement();
        String sql = """
            SELECT t.TrackId, t.TrackName, t.Album, t.MilliSeconds, t.Bytes, t.UnitPrice, a.Name
            FROM Tracks t
            INNER JOIN Artists a ON t.ArtistId = a.ArtistId
        """;
        List<TrackQuery> results = new ArrayList<>();
        rs = st.executeQuery(sql);
        while (rs.next()) {
            int id = rs.getInt("TrackId");
            String name = rs.getString("TrackName");
            String album = rs.getString("Album");
            int ms = rs.getInt("MilliSeconds");
            int bytes = rs.getInt("Bytes");
            double price = rs.getDouble("UnitPrice");
            String artistName = rs.getString("Name");

            TrackQuery tq = new TrackQuery(id, name, album, ms, bytes, price, artistName);
            results.add(tq);
        }
        return results;
    } catch (SQLException e) {
        System.out.println("Hiba getAll(): " + e.getMessage());
        return null;
    } finally {
        try {
            if (rs != null) {
                rs.close();
            }
            if (st != null) {
                st.close();
            }
        } catch (SQLException e) {
            System.out.println("Hiba a Statement és ResultSet lezárásánál: " + e.getMessage());
        }
    }
}


    public Track getLongest() {
    Statement st = null;
    ResultSet rs = null;
    try {
        st = getStatement(); // Az adatbázis kapcsolatot egyszer hozzuk létre
        String sql = "SELECT * FROM Tracks ORDER BY MilliSeconds DESC LIMIT 1";
        rs = st.executeQuery(sql);

        if (rs.next()) {
            return new Track(
                rs.getInt("TrackId"),
                rs.getString("TrackName"),
                rs.getString("Album"),
                rs.getInt("MilliSeconds"),
                rs.getInt("Bytes"),
                rs.getDouble("UnitPrice"),
                rs.getInt("ArtistId")
            );
        } else {
            return null;
        }
    } catch (SQLException e) {
        System.out.println("Hiba getLongest(): " + e.getMessage());
        return null;
    } finally {
        // Zárd le a ResultSet és Statement objektumokat
        try {
            if (rs != null) rs.close();
            if (st != null) st.close(); // Zárd le a Statement-et
        } catch (SQLException e) {
            System.out.println("Hiba a Statement és ResultSet zárásakor: " + e.getMessage());
        }
    }
}


    public int getRocks() {
        Statement st = null;
        ResultSet rs = null;
        try {
            st = getStatement();
            String sql = "SELECT COUNT(*) as cnt FROM Tracks WHERE LOWER(TrackName) LIKE '%rock%'";
            rs = st.executeQuery(sql);
            if (rs.next()) {
                return rs.getInt("cnt");
            } else {
                return 0;
            }
        } catch (SQLException e) {
            System.out.println("Hiba getRocks(): " + e.getMessage());
            return 0;
        }finally {
        // Zárd le a ResultSet és Statement objektumokat
        try {
            if (rs != null) rs.close();
            if (st != null) st.close(); // Zárd le a Statement-et
        } catch (SQLException e) {
            System.out.println("Hiba a Statement és ResultSet zárásakor: " + e.getMessage());
        }
    }
    }

    public boolean addTrack(Track track) {
        String sql = "INSERT INTO Tracks (TrackName, Album, MilliSeconds, Bytes, UnitPrice, ArtistId) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, track.getTrackName());
            ps.setString(2, track.getAlbum());
            ps.setInt(3, track.getMilliSeconds());
            ps.setInt(4, track.getBytes());
            ps.setDouble(5, track.getUnitPrice());
            ps.setInt(6, track.getArtistId());

            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            System.out.println("Hiba addTrack(): " + e.getMessage());
            return false;
        }
    }

    public boolean updateTrack(int trackId, double newPrice) {
        String sql = "UPDATE Tracks SET UnitPrice = ? WHERE TrackId = ?";
        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDouble(1, newPrice);
            ps.setInt(2, trackId);

            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            System.out.println("Hiba updateTrack(): " + e.getMessage());
            return false;
        }
    }
}



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.musicapp;

/**
 *
 * @author lalat
 */

import java.util.List;

public class MusicApp {

    public static void main(String[] args) 
    {
        // MusicRepository példányosítása
        MusicRepository musicRepo = new MusicRepository();

        // 1. Összes zene lekérése
        List<TrackQuery> tracks = musicRepo.getAll();
        if (tracks != null) {
            System.out.println("Összes zene:");
            for (TrackQuery track : tracks) {
                System.out.println(track);
            }
        }

        // 2. Leghosszabb zene lekérése
        Track longestTrack = musicRepo.getLongest();
        if (longestTrack != null) {
            System.out.println("\nLeghosszabb zene: " + longestTrack);
        }

        // 3. "rock" szó előfordulása
        int rockCount = musicRepo.getRocks();
        System.out.println("\nA 'rock' szót tartalmazó zenék száma: " + rockCount);

        // 4. Új zene hozzáadása
        Track newTrack = new Track(3504, "New Rock Song", "Rock Album", 300000, 5000000, 1.99, 1);
        boolean isAdded = musicRepo.addTrack(newTrack);
        System.out.println("\nÚj zene hozzáadása: " + (isAdded ? "Sikeres" : "Hibás"));

        // 5. Zene árának frissítése
        boolean isUpdated = musicRepo.updateTrack(longestTrack.getTrackId(), 2.99);
        System.out.println("\nZene ára frissítve: " + (isUpdated ? "Sikeres" : "Hibás"));
    }
}
